<?php
include('connection.php');
session_start();
$username_session = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Brgy Blotter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }

        a {
            text-decoration: none;
        }

        .list-group-item {
          border: none !important;
          margin-left: 10px;
        }

        .ml-left { 
        margin-left: 10px;
        margin-top: 10px; }


       .list-group-item:hover {
        background: white !important;
        color:  #1e1ee7 !important;


      }

      .dphidden{
       display: none;

      }

</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('brgy_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>In Progress Complaints</h1><br>
                <div class="row">              
                <?php 
                    $res = mysqli_query($conn, "SELECT * FROM tbl_complaints WHERE barangay='$username_session' AND status='In Progress' ORDER BY id DESC");
                
                ?>       
                <?php while($row = mysqli_fetch_array($res)){ ?>         
                      <div class="col-lg-12 ">
                          <div class="card border-primary" >
                                <div class="card-header text-black" style="font-size: 1.5rem;"><?php echo $row["case_id"]; ?></div>
                                  <ul class='list-group' >  


                                  <label class="ml-left">ID: 
                                    <?php echo $row["id"]; ?></label>
                                    <li class="list-group-item list-group-item-success dphidden"><?php echo $row["id"]; ?> 
                                  </li>

                                   <label class="ml-left">Case ID: 
                                    <?php echo $row["case_id"]; ?>
                                    </label>

                                    <label class="ml-left">Barangay: 
                                      <?php echo $row["barangay"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["barangay"]; ?> 
                                    </li>

                                    <label class="ml-left">Complainant Name: 
                                      <?php echo $row["complainant_name"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_name"]; ?> 
                                    </li>

                                    <label class="ml-left">Complainant Address: 
                                      <?php echo $row["complainant_address"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_address"]; ?> 
                                    </li>

                                    <label class="ml-left">Complainant Age: 
                                      <?php echo $row["complainant_age"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_age"]; ?> 
                                    </li>

                                    <label class="ml-left">Respondent Name: 
                                      <?php echo $row["respondent_name"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_name"]; ?> 
                                    </li>


                                    <label class="ml-left">Respondent Address: 
                                      <?php echo $row["respondent_address"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_address"]; ?> 
                                    </li>

                                    <label class="ml-left">Respondent Age: 
                                      <?php echo $row["respondent_age"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_age"]; ?> 
                                    </li>

                                    <label class="ml-left">Brief of the Case: 
                                      <?php echo $row["brief_of_the_case"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["brief_of_the_case"]; ?> 
                                    </li>

                                    <label class="ml-left">Status: 
                                      <?php echo $row["status"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["status"]; ?> 
                                    </li>

                                    <label class="ml-left">Date: 
                                      <?php echo $row["date"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["date"]; ?> 
                                    </li>

                                    <label class="ml-left">Time: 
                                      <?php echo $row["time"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["time"]; ?> 
                                    </li>

                                    <label class="ml-left">Remarks: 
                                      <?php echo $row["remarks"]; ?></label>
                                      <li class="list-group-item list-group-item-success dphidden"><?php echo $row["remarks"]; ?> 
                                    </li>





                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["case_id"]; ?> </li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["barangay"]; ?> </li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_name"]; ?></li> 

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_address"]; ?></li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["complainant_age"]; ?></li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_name"]; ?></li>   

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_address"]; ?></li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["respondent_age"]; ?></li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["brief_of_the_case"]; ?></li>

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["status"]; ?></li> 

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["date"]; ?></li> 

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["time"]; ?></li> 

                                  <li class="list-group-item list-group-item-success dphidden"><?php echo $row["remarks"]; ?></li> 

                                  <li class="list-group-item list-group-item-success"><button class="btn btn-primary editBtnAdmin " data-toggle="modal" data-target="#editBtnAdmin">Solve It</button>
                                  </li>
                               
                               
                              </ul>
                          </div>  
                      </div>
                      <?php
                   }
                ?>  
                </div>
            </div>

            <div id="editBtnAdmin" class="modal fade" role="">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <form action="" method="post">
                  <div class="modal-header">
                    <h4 class="modal-title">Update</h4>
                  </div>     
                  <div class="modal-body">      
                    <input id="update_admin_id" name="update_admin_id" type="hidden">

                    <div class="form-group">
                      <label for="usr">Case ID:</label>
                      <input type="text" name="case_id" id="case_id"  class="form-control" readonly>
                    </div>

                      <div class="form-group">
                        <label for="usr">Complainant Name:</label>
                        <input type="text" name="complainant_name" id="complainant_name"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Address:</label>
                        <input type="text" name="complainant_address" id="complainant_address"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Age:</label>
                        <input type="text" name="complainant_age" id="complainant_age"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Name:</label>
                        <input type="text" name="respondent_name" id="respondent_name"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Address:</label>
                        <input type="text" name="respondent_address" id="respondent_address"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Age:</label>
                        <input type="text" name="respondent_age" id="respondent_age"  class="form-control" readonly>
                      </div>
                      <div class="form-group">
                        <label for="usr">Brief of the Case:</label>
                        <input type="text" name="brief_of_the_case" id="brief_of_the_case"  class="form-control" readonly>
                      </div>

                      <div class="form-group">
                        <label for="usr">Status:</label>
                        <select class="form-control" name="status" id="status">
                            <option selected disabled>Choose your status</option>
                            <option disabled value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                            <option value="Unresolved">Unresolved</option>
                        </select>
                      </div> 

                      <div class="form-group">
                        <label for="usr">Remarks:</label>
                        <input type="text" name="remarks" id="remarks" class="form-control">
                      </div> 





                    </div>

                    <div class="modal-footer">
                      <button type="submit" name="updateData" class="btn btn-primary">Update</button>
                      <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
                    </div>
                  </form>
                </div>
              </div>
            </div>     

            <?php 
               if(isset($_POST['updateData'])){    
                 $id = $_POST['update_admin_id'];
                                  $status = mysqli_real_escape_string($conn, $_POST["status"]);
                                  $remarks = mysqli_real_escape_string($conn, $_POST["remarks"]);
                                  $query = mysqli_query($conn, "UPDATE tbl_complaints 
                                                  SET 
                                                  status='$status', 
                                                  remarks='$remarks'
                                                  WHERE id='$id'");

                                  if ($query) {
                                      $_SESSION['success'] = 'Successfully Updated';
                                      echo '<script> window.location="brgy_complaints_pending.php";</script>';
                                      exit(); // Terminate the script after redirection
                                  } else {
                                      $_SESSION['error'] = 'Update Failed';
                                      echo '<script> window.location="brgy_complaints_pending.php";</script>';
                                      exit(); // Terminate the script after redirection
                                  }
                              }
            ?>




              

        
    </div>
    <!-- Bootstrap core JS-->
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>



<script>



  $(document).ready( function () {
       $('.example').DataTable();
     });



   $(document).ready(function(){
       $('.deleteAdmin').on('click', function(){
           $tr = $(this).closest('tr');
           var data = $tr.children("li").map(function(){
               return $(this).text();
     //          console.log(data);
           }).get();
           $('#delete_id').val(data[0]);          
       });
   });
    
    $(document).ready(function(){
        $('.editBtnAdmin').on('click', function(){      
                $tr = $(this).closest('ul');
                var data = $tr.find("li.list-group-item").map(function(){
                    return $(this).text();
                }).get();

                 $('#update_admin_id').val(data[0]);
                 $('#case_id').val(data[0]);
                 $('#barangay').val(data[1]);
                 $('#complainant_name').val(data[2]);
                 $('#complainant_address').val(data[3]); 
                 $('#complainant_age').val(data[4]);
                 $('#respondent_name').val(data[5]); 
                 $('#respondent_address').val(data[6]); 
                 $('#respondent_age').val(data[7]); 
                 $('#brief_of_the_case').val(data[8]); 
                 $('#date').val(data[9]); 
                 $('#time').val(data[10]);   
                 $('#remarks').val(data[25]);   



        });
     });
</script>