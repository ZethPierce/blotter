<?php 
require_once "controlleruserdata.php"; 
include('connection.php');
include('tags.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="style.css">
    <style>
        .borderimg {
            border: solid 1px black; padding: 5px 35px 5px 35px; border-radius: 5px; margin-top: 15px; margin-bottom: 15px;
        }
        .btn-primary {
            background: #3d96ff;
            border-color: #3d96ff;
        }
        .btn-primary:hover {
            background: #1577ea;
            border-color: #1577ea;
        }
        .btn-admin{
            background: #468598; 
            color: white; 
            margin-top: 15px;
        }
        .btn-admin:hover{
            background: #1e677d; 

        }

    </style>
</head>
<body>
    <div class="container" style="max-width: 350px; zoom: 120%;">
        <div style="font-size: 2rem; margin-top: 15px; margin-left: -25px;">
            <!-- <a href="homepage/index.php"><button class="btn btn-light">Back</button></a> -->
        </div> 
        <div class="row text-center align-items-center h-100 mx-auto justify-content-center align-items-center" style="">
            <div class="login-form ">
                 <img class="img-fluid" src="img/logo.png" width="150">
                <form action="" method="POST" autocomplete="">
                    <!-- <h2 class="text-center">Login Form</h2>
                    <p class="text-center">Login with your username and password.</p> -->
                    <?php 
                         if(isset($_POST["register"])) {
                           $name = mysqli_real_escape_string($conn, $_POST['name']);
                      
                           $contact_no = mysqli_real_escape_string($conn, $_POST['contact_no']);
                           $address = mysqli_real_escape_string($conn, $_POST['address']);
                           $username = mysqli_real_escape_string($conn, $_POST['username']);
                           $password = mysqli_real_escape_string($conn, $_POST['password']);

        
                             
                            $query_insert = mysqli_query($conn, "INSERT INTO tbl_user_credentials 
                                      VALUES('', '$name', '$email', 
                                        '$contact_no', '$address', '$username', '$password')");
                                    if($query_insert)
                                    {            
                                        echo '<div class="alert alert-success">Your Account is Successfully Registered</div>';
                                                    
                                    }
                        
                        }
                    ?>
    
                    <hr/>
                    <div style="text-align: left !important;">
                    <div class="form-group" >
                        <label>Name:</label>
                        <input class="form-control"  type="text" name="name"  required >
                    </div>
                    <div class="form-group">
                        <label>Contact No:</label>
                        <input class="form-control" type="number" name="contact_no"  required>
                    </div>
                    <div class="form-group">
                        <label>Address:</label>
                        <input class="form-control" type="text" name="address" required>
                    </div>
                    <div class="form-group">
                        <label>Username:</label>
                        <input class="form-control" type="text" name="username" required>
                    </div>


                    <div class="form-group">
                        <label>Password:</label>
                        <input class="form-control" type="password" name="password" id="password" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password:</label>
                        <input class="form-control" type="password" id="confirmPassword" required>
                    </div>

                    <span id="passwordMatchStatus"></span>

                    <!-- <span style="text-align: right !important; margin-top: -10px; margin-bottom: 15px; float: right;">Forgot as Password</span> -->
                   
                    <div class="form-group">
                        <input class="form-control button btn-primary" id="registerBtn" disabled type="submit" name="register" value="Register" >
                    </div>
                </div>


                    <a href="user_login.php">Already Registered?</a>
                
                </form>
            </div>
        </div>
    </div>
    
</body>


</html>

<script>
  var passwordInput = document.getElementById("password");
  var confirmPasswordInput = document.getElementById("confirmPassword");
  var registerBtn = document.getElementById("registerBtn");

  function validatePassword() {
     var password = passwordInput.value;
     var confirmPassword = confirmPasswordInput.value;

     if (password === confirmPassword) {
       passwordMatchStatus.textContent = "Password matches";
       passwordMatchStatus.style.color = "green";
       registerBtn.disabled = false;
     } else {
       passwordMatchStatus.textContent = "Password does not match";
       passwordMatchStatus.style.color = "red";
       registerBtn.disabled = true;
     }
   }

  passwordInput.addEventListener("input", validatePassword);
  confirmPasswordInput.addEventListener("input", validatePassword);
</script>