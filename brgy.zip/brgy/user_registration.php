<?php 
require_once "controlleruserdata.php"; 
include('connection.php');
include('tags.php');


$rand = rand(9999,1000);



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="style.css">
    <style>
        .borderimg {
            border: solid 1px black; padding: 5px 35px 5px 35px; border-radius: 5px; margin-top: 15px; margin-bottom: 15px;
        }
        .btn-primary {
            background: #3d96ff;
            border-color: #3d96ff;
        }
        .btn-primary:hover {
            background: #1577ea;
            border-color: #1577ea;
        }
        .btn-admin{
            background: #468598; 
            color: white; 
            margin-top: 15px;
        }
        .btn-admin:hover{
            background: #1e677d; 

        }

    </style>
</head>
<body>
    <!-- <a href="homepage/index.php" ><button class="btn btn-light" style="margin-top: 50px; margin-left: 50px;">Back</button></a> -->
    <div class="container" style="max-width: 350px; zoom: 120%;">
        <div style="font-size: 2rem; margin-top: 15px; margin-left: -25px;">
           
        </div> 
        <div class="row text-center align-items-center h-100 mx-auto justify-content-center align-items-center" style="">
            <?php
                      // Check if the success message is set in the session and display it
                      if (isset($_SESSION['success'])) {
                          echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                          unset($_SESSION['success']); // Clear the success message from the session
                      }
                      else if (isset($_SESSION['danger'])) {
                          echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                          unset($_SESSION['danger']); // Clear the success message from the session
                      }

                      ?>
            <div class="login-form ">
                 <a href="index.php"><img class="img-fluid" src="img/logo.png" width="150"></a>
                <form action="" method="POST" autocomplete="">
                    <!-- <h2 class="text-center">Login Form</h2>
                    <p class="text-center">Login with your username and password.</p> -->
                    <?php 
                         if(isset($_POST["addData"]))
                            {
                                $rand = rand(9999,1000);
                               $case_id = mysqli_real_escape_string($conn, $_POST["case_id"]);
                               $barangay = mysqli_real_escape_string($conn, $_POST["barangay"]);
                               $username = mysqli_real_escape_string($conn, $_POST["username"]);
                               $password = mysqli_real_escape_string($conn, $_POST["password"]);
                               $complainant_name = mysqli_real_escape_string($conn, $_POST["complainant_name"]);
                               $complainant_address = mysqli_real_escape_string($conn, $_POST["complainant_address"]);  
                               $complainant_age = mysqli_real_escape_string($conn, $_POST["complainant_age"]);
                               $respondent_name = mysqli_real_escape_string($conn, $_POST["respondent_name"]);
                               $respondent_address = mysqli_real_escape_string($conn, $_POST["respondent_address"]);  
                               $respondent_age = mysqli_real_escape_string($conn, $_POST["respondent_age"]);
                               $brief_of_the_case = mysqli_real_escape_string($conn, $_POST["brief_of_the_case"]);
                               $status = "Pending";
                               date_default_timezone_set('Asia/Manila');
                               $date = date("Y-m-d"); // Current date in the format YYYY-MM-DD
                               $time = date("H:i:s"); // Current time in the format HH:MM:SS (24-hour format)

                               $captcha = $_REQUEST['captcha'];
                               $captcharandom = $_REQUEST['captcha-rand'];

                               $query_show = mysqli_query($conn, "SELECT * FROM tbl_complaints");
       
                                     echo '<script> window.location="user_registration.php";</script>';       
                                
                              
                                     //else, i-eexecute nya yung insert query
                                     $query_insert = mysqli_query($conn, "INSERT INTO tbl_complaints 
                                         VALUES('', '$case_id', '$barangay', '$username', '$password',
                                           '$complainant_name', '$complainant_address', '$complainant_age',
                                           '$respondent_name', '$respondent_address', '$respondent_age',
                                           '$brief_of_the_case', '$status', '$date', '$time', 'NULL')");
                                       if($query_insert)
                                       {            
                                         $_SESSION['success'] = 'Data Inserted'; // Set the success message in the session
                                          echo '<script> window.location="user_registration.php";</script>';                        
                                       }
                                   
                                    else {
                                        $msg = "<div class='alert alert-danger'>Incorrect captcha value!</div>";
                                    }
                                 
                             }


                    ?>
                    <hr/>
                    <div style="text-align: left !important;">

                  

                    <div class="form-group">
                       <!-- <?php 
                            $sql = 'SELECT MAX(id) AS latest_id FROM tbl_complaints';
                            $result = mysqli_query($conn, $sql);
                            $latest_id = mysqli_fetch_assoc($result)['latest_id'];
                       ?>
                      <label for="usr">Case ID:</label>
                      <input type="text" name="case_id" class="form-control" required value="<?php echo $latest_id + 1; ?>"> -->
                      <?php 
                      date_default_timezone_set('Asia/Manila');
                      $date = date("Ymd");
                      $time = date("H:i:s");

                      ?>
                      <label for="usr">Case Number:</label>
                      <input type="text" name="case_id"  class="form-control" readonly required value="<?php echo "KP", $date, "-", $time; ?>">



                    </div>

                    <div class="form-group">
                      <label for="usr">Barangay:</label>
                      <select class="form-control" name="barangay">
                                <option disabled selected>--Select a Barangay--</option>
                                  <?php 
                                  $res2 = mysqli_query($conn, "SELECT username FROM tbl_brgy_credentials");
                                  while($row = mysqli_fetch_array($res2)){ 
                                    ?>
                                    <option value="<?php echo $row['username']; ?>"><?php echo $row["username"]; ?></option>
                                    <?php 
                                  } 
                                  ?>
                        </select>
                    </div>
                    <div class="form-group">
                      <label for="usr">Username:</label>
                      <input type="text" name="username" class="form-control">
                    </div>

                    <div class="form-group">
                      <label for="usr">Password:</label>
                      <input type="password" name="password" class="form-control">
                    </div>
                    <div class="form-group">
                      <label for="usr">Complainant Address:</label>
                      <input type="text" name="complainant_address" class="form-control">
                    </div>
                    <div class="form-group">
                      <label for="usr">Complainant Age:</label>
                      <input type="number" name="complainant_age" class="form-control">
                    </div>

                    <div class="form-group">
                      <label for="usr">Respondent Name:</label>
                      <input type="text" name="respondent_name" class="form-control">
                    </div>
                    <div class="form-group">
                      <label for="usr">Respondent Address:</label>
                      <input type="text" name="respondent_address" class="form-control">
                    </div>
                    <div class="form-group">
                      <label for="usr">Respondent Age:</label>
                      <input type="number" name="respondent_age" class="form-control">
                    </div>
                    <div class="form-group">
                      <label for="usr">Brief of the Case:</label>
                      <textarea name="brief_of_the_case" class="form-control"></textarea>
                    </div>

                    <div class="input-group display-inline">
                      <input type="hidden" name="captcha-rand" value="<?php echo $rand; ?>">
                      <div class="input-group-append">
                        <span class="input-group-text font-weight-bold"><?php echo $rand; ?></span>
                        <input type="text" class="form-control required" name="captcha" id="captcha" data-parsley-trigger="keyup" placeholder="Enter Your Captcha" required>
                        <br><br><br>
                        <!-- <button class="btn btn-success" type="submit">Go</button> -->
                      </div>




                    </div>

                    

                    <!-- <span style="text-align: right !important; margin-top: -10px; margin-bottom: 15px; float: right;">Forgot as Password</span> -->
                   
                     <div class="form-group">
                        <input class="form-control button btn-primary" id="registerBtn"  type="submit" name="addData" value="File a Complaint" >
                    </div> 
                    <!-- <button type="submit" name="addData" class="btn btn-primary">File a Complaint</button> -->
                </div>


                    <!-- <a href="user_login.php">Already Registered?</a> -->
                
                </form>
            </div>
        </div>
    </div>
    
</body>


</html>

<script>
  var passwordInput = document.getElementById("password");
  var confirmPasswordInput = document.getElementById("confirmPassword");
  var registerBtn = document.getElementById("registerBtn");

  function validatePassword() {
     var password = passwordInput.value;
     var confirmPassword = confirmPasswordInput.value;

     if (password === confirmPassword) {
       passwordMatchStatus.textContent = "Password matches";
       passwordMatchStatus.style.color = "green";
       registerBtn.disabled = false;
     } else {
       passwordMatchStatus.textContent = "Password does not match";
       passwordMatchStatus.style.color = "red";
       registerBtn.disabled = true;
     }
   }

  passwordInput.addEventListener("input", validatePassword);
  confirmPasswordInput.addEventListener("input", validatePassword);
</script>

<script>
function updateTime() {
  var time = new Date();
  var hours = time.getHours();
  var minutes = time.getMinutes();
  var seconds = time.getSeconds();

  // Format the time
  var formattedTime = hours + ':' + minutes + ':' + seconds;

  // Set the time of the HTML element with the id "time"
  document.getElementById("time").innerHTML = formattedTime;
}

// Update the time every second
setInterval(updateTime, 1000);
</script>