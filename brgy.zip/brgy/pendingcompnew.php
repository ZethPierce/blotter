<div class="card-body ">   
                                                <h6><?php echo $row["id"]; ?> </h6>
                                                <h6><?php echo $row["complainant_name"]; ?></h6>           
                                                <h6><?php echo $row["complainant_address"]; ?></h6>
                                                <h6><?php echo $row["complainant_age"]; ?></h6>
                                                <h6><?php echo $row["respondent_name"]; ?></h6>           
                                                <h6><?php echo $row["respondent_address"]; ?></h6>
                                                <h6><?php echo $row["respondent_age"]; ?></h6>
                                                <h6><?php echo $row["brief_of_the_case"]; ?></h6>
                                                <h6><?php echo $row["status"]; ?></h6> 
                                                <h6><?php echo $row["date"]; ?></h6> 
                                                <h6><?php echo $row["time"]; ?></h6> 
                                                <h6><button class="btn btn-primary editBtnAdmin " data-toggle="modal" data-target="#editBtnAdmin">Solve It</button>
                                                </h6>                               
                                          </div>  