<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Brgy Blotter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }


</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('user_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>File a Complaint</h1><br>
                <div class="row">
                        <form action="" method="post">                                       
                              <div class="form-group">
                                <label for="usr">Barangay:</label>
                                <select class="form-control" name="barangay">
                                <option disabled selected>--Select a Barangay--</option>
                                  <?php 
                                  $res2 = mysqli_query($conn, "SELECT username FROM tbl_brgy_credentials");
                                  while($row = mysqli_fetch_array($res2)){ 
                                    ?>
                                    <option value="<?php echo $row['username']; ?>"><?php echo $row["username"]; ?></option>
                                    <?php 
                                  } 
                                  ?>
                                </select>
                              </div>


                              <div class="form-group mt-2">
                                <label for="usr">--Nature Incident:</label>
                                <select class="form-control" name="nature_of_incident">
                                    <option disabled selected>--Select an Incident--</option>
                                    <option value="Civil Case">Civil Case</option>
                                    <option value="Criminal Case">Criminal Case</option>
                                    <option value="Others">Others</option>
                                </select>
                              </div>

                              <div class="form-group mt-2">
                                <label for="usr">Incident Name:</label>
                                <input type="text" name="incident_name" class="form-control">
                              </div>

                              <div class="form-group mt-2">
                                <label for="usr">Phone Number:</label>
                                <input type="number" name="phone_number" class="form-control">
                              </div>

                              <div class="form-group mt-2 mb-2">
                                <label for="usr">Complaint:</label>
                                <textarea type="text" name="complaint" class="form-control" required></textarea>
                              </div>    
              
                              <button type="submit" name="addData" class="btn btn-primary">Add Data</button>
                      
                           
                          </form>
                </div>


                <?php 
                  if(isset($_POST["addData"]))
                     {
                      
                        $username = $_SESSION['username'];
                        $barangay = mysqli_real_escape_string($conn, $_POST["barangay"]);
                        $complaint = mysqli_real_escape_string($conn, $_POST["complaint"]);  
                        $status = "Pending";
                        date_default_timezone_set('Asia/Manila');
                        $date = date("Y-m-d"); // Current date in the format YYYY-MM-DD
                        $time = date("H:i:s"); // Current time in the format HH:MM:SS (24-hour format)
                        $phone_number = mysqli_real_escape_string($conn, $_POST["phone_number"]);
                        $nature_of_incident = mysqli_real_escape_string($conn, $_POST["nature_of_incident"]);
                         $incident_name = mysqli_real_escape_string($conn, $_POST["incident_name"]);

                        $query_show = mysqli_query($conn, "SELECT * FROM complaints");
                              $query_insert = mysqli_query($conn, "INSERT INTO complaints 
                                  VALUES('', '$username', '$barangay', 
                                  '$complaint', 'NULL', '$status', '$date', '$time', '$phone_number', '$nature_of_incident', '$incident_name')");
                                if($query_insert)
                                {            
                                  $_SESSION['success'] = 'Data Inserted'; // Set the success message in the session
                                   echo '<script> window.location="user_file_complaint.php";</script>';                        
                                }                  
                          
                      }

                     if(isset($_POST['deleteData'])){    
                        $id = $_POST['delete_id'];
                        $query = mysqli_query($conn, "DELETE FROM complaints WHERE id='$id'");
                        if($query) {
                          $_SESSION['success'] = 'Data Deleted'; // Set the success message in the session
                          echo '<script> window.location="user_file_complaint.php";</script>';              
                         
                        }
                     }
                ?>  

              

        
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>


