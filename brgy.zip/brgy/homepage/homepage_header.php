      <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav" style="padding: 0px; background: white;">
            <div class="container-fluid">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">
                    <img class="img-fluid" src="../img/petmalu_logo.png" width="150" style="height: 80px;">
            </a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ml-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                  <ul class="navbar-nav text-uppercase ml-auto">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Services</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#gallery">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#aboutus">About Us</a></li>
                    
                    <?php
                    session_start();
                    if (isset($_SESSION['username'])) {
                      $username = $_SESSION['username'];
                      echo '<li class="nav-item"><a class="nav-link js-scroll-trigger" href="user_appointment.php">My Appointment</a></li>';
                      echo '<li class="nav-item"><a style="padding: 0.5rem 3rem;" class="nav-link js-scroll-trigger log-in-border" href="#">' . $username . '</a></li>';
                       echo '<li class="nav-item"><a style="padding: 0.5rem 3rem;" class="nav-link js-scroll-trigger log-in-border" href="../logout.php">Log Out</a></li>';

                    } else {
                      echo '<li class="nav-item"><a style="padding: 0.5rem 3rem;" class="nav-link js-scroll-trigger log-in-border" href="../user_login.php">Log In</a></li>';


                      echo ' <li class="nav-item"><a style="padding: 0.5rem 3rem;" class="nav-link js-scroll-trigger log-in-border" href="../user_registration.php">Register</a></li>';


                    }
                    ?>
                    
                   
                  </ul>

                </div>
            </div>
        </nav>