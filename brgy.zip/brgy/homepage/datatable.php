<?php
    include('connection.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>DataTable Example</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.css"/>
  </head>
  <body>
    <?php 
       $res = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials");
       if($res){
         $rowcount = mysqli_num_rows($res);
       }
       
       ?>    
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                              <th>Last Name</th>
                              <th>First Name</th>
                              <th>Middle Name</th>
                              <th>Username</th>
                              <th>Password</th>
                              <th>Edit</th> 
                              <th>Delete</th>         
            </tr>
        </thead>
        <tbody>
             <?php while($row = mysqli_fetch_array($res)){ ?>
            <tr>  
              <td><?php echo $row["id"]; ?> </td>
              <td><?php echo $row["last_name"]; ?></td>
              <td><?php echo $row["first_name"]; ?></td>
              <td><?php echo $row["middle_name"]; ?></td>           
              <td><?php echo $row["username"]; ?></td>
              <td><?php echo $row["password"]; ?></td>                 
              <td><?php echo '<button class="btn btn-warning editBtnAdmin" data-toggle="modal" data-target="#editBtnAdmin">Edit</button>' ?> </td>
              <td><?php echo '<button class="btn btn-danger deleteAdmin" data-toggle="modal" data-target="#deleteAdmin">Delete</button>' ?> </td>
            </tr>
             <?php
             }
            ?>
        </tbody>
    </table>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.js"></script>
    <script>
      $(document).ready( function () {
        $('#example').DataTable();
      });
    </script>
  </body>
</html>
