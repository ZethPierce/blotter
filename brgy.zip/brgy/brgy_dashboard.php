<?php
include('connection.php');
session_start();
$username_session = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Brgy Blotter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }

        a {
            text-decoration: none;
        }


</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('brgy_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>Dashboard</h1><br>
                <div class="row">                  
                      <div class="col-lg-3 ">
                          <div class="card  bg-primary  mb-3" >
                             <a href="brgy_complaints_pending.php">
                                <div class="card-header text-white">Total Pending Complaints</div>
                                <div class="card-body text-white">
                                <?php 
                                    $res = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_complaints WHERE status='Pending' AND barangay='$username_session'");
                                    $row = mysqli_fetch_array($res);
                                    $total = $row[0];
                                ?>                            
                                  <h1 class="card-title"><?php echo $total; ?></h1>                    
                                  <p class="card-text">Overall Total of Pending Complaints</p>
                                </div>
                             </a>
                          </div>
                      </div>
                      <div class="col-lg-3">
                          <div class="card bg-secondary mb-3" >
                            <a href="brgy_complaints_inprogress.php">
                            <div class="card-header text-white">Total In Progress Complaints</div>
                            <div class="card-body text-white">
                            <?php 
                                $res = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_complaints WHERE status='In Progress' AND barangay='$username_session'");
                                $row = mysqli_fetch_array($res);
                                $total = $row[0];
                            ?>                            
                              <h1 class="card-title"><?php echo $total; ?></h1>                    
                              <p class="card-text">Overall Total of In Progress Complaints.</p>
                            </div>
                        </a>
                          </div>
                      </div>
                      <div class="col-lg-3">
                          <div class="card  bg-success  mb-3" >
                            <a href="brgy_complaints_completed.php">
                            <div class="card-header text-white">Total Completed Complaints</div>
                            <div class="card-body text-white">
                            <?php 
                                $res = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_complaints WHERE status='Completed' AND barangay='$username_session'");
                                $row = mysqli_fetch_array($res);
                                $total = $row[0];
                            ?>                            
                              <h1 class="card-title"><?php echo $total; ?></h1>                    
                              <p class="card-text">Overall Total of Completed Complaints.</p>
                            </div>
                             </a>
                          </div>
                      </div>
                      <div class="col-lg-3">
                          <div class="card  bg-danger  mb-3" >
                            <a href="brgy_complaints_unresolved.php">
                            <div class="card-header text-white">Total Unresolved Complaints</div>
                            <div class="card-body text-white">
                            <?php 
                                $res = mysqli_query($conn, "SELECT COUNT(1) FROM tbl_complaints WHERE status='Unresolved' AND barangay='$username_session'");
                                $row = mysqli_fetch_array($res);
                                $total = $row[0];
                            ?>                            
                              <h1 class="card-title"><?php echo $total; ?></h1>                    
                              <p class="card-text">Overall Total of Unresolved Complaints.</p>
                            </div>
                        </a>
                          </div>
                      </div>
                </div>

            </div>
              

        
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>


