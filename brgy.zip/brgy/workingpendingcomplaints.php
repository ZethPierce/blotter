<?php
include('connection.php');
session_start();
$username_session = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Brgy Blotter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }

        a {
            text-decoration: none;
        }



</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('brgy_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>Pending Complaints</h1><br>
                <div class="row">              
                <?php 
                    $res = mysqli_query($conn, "SELECT * FROM tbl_complaints WHERE barangay='$username_session' AND status='Pending' ORDER BY id DESC");
                
                ?>    

                <?php while($row = mysqli_fetch_array($res)){ ?>  
                  <table class='table table-bordered table-striped example'  style="width:100%">
                    <thead>
                        <th>ID</th>
                        <th>Complainant Name</th>
                        <th>Complainant Address</th>
                        <th>Complainant Age</th>
                        <th>Respondent Name</th>
                        <th>Respondent Address</th>
                        <th>Respondent Age</th>
                        <th>Brief of the Case</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>View</th>        
                    </thead> 
                    <tbody>
                     <tr>
                     <td><?php echo $row["id"]; ?> </td>
                     <td><?php echo $row["complainant_name"]; ?></td>           
                     <td><?php echo $row["complainant_address"]; ?></td>
                     <td><?php echo $row["complainant_age"]; ?></td>
                     <td><?php echo $row["respondent_name"]; ?></td>           
                     <td><?php echo $row["respondent_address"]; ?></td>
                     <td><?php echo $row["respondent_age"]; ?></td>
                     <td><?php echo $row["brief_of_the_case"]; ?></td>
                     <td><?php echo $row["status"]; ?></td> 
                     <td><?php echo $row["date"]; ?></td> 
                     <td><?php echo $row["time"]; ?></td> 
                     <td><button class="btn btn-primary editBtnAdmin " data-toggle="modal" data-target="#editBtnAdmin">Solve It</button>
                     </td>
                    </tr>
                  </tbody>
                      <?php
                   }
                ?>  
                
            </div>
             <?php 
              
              if (isset($_POST['updateData'])) {
                  $id = $_POST['update_admin_id'];
                  $status = mysqli_real_escape_string($conn, $_POST["status"]);
                  $remarks = mysqli_real_escape_string($conn, $_POST["remarks"]);
                  $query = mysqli_query($conn, "UPDATE tbl_complaints 
                                  SET 
                                  status='$status', 
                                  remarks='$remarks'
                                  WHERE id='$id'");

                  if ($query) {
                      $_SESSION['success'] = 'Successfully Updated';
                      echo '<script> window.location="brgy_complaints_pending.php";</script>';
                      exit(); // Terminate the script after redirection
                  } else {
                      $_SESSION['error'] = 'Update Failed';
                      echo '<script> window.location="brgy_complaints_pending.php";</script>';
                      exit(); // Terminate the script after redirection
                  }
              }
            ?>

            <div id="editBtnAdmin" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <form action="" method="post">
                  <div class="modal-header">
                    <h4 class="modal-title">Update</h4>
                  </div>     
                  <div class="modal-body">      
                    <input id="update_admin_id" name="update_admin_id" type="hidden">

                      <div class="form-group">
                        <label for="usr">Complainant Name:</label>
                        <input type="text" name="complainant_name" id="complainant_name" readonly class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Complainant Address:</label>
                        <input type="text" name="complainant_address" id="complainant_address" readonly class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Complainant Age:</label>
                        <input type="text" name="complainant_age" id="complainant_age" readonly class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Name:</label>
                        <input type="text" name="respondent_name" id="respondent_name" readonly class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Address:</label>
                        <input type="text" name="respondent_address" id="respondent_address" readonly class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Respondent Age:</label>
                        <input type="text" name="respondent_age" id="respondent_age" readonly class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Brief of the Case:</label>
                        <input type="text" name="brief_of_the_case" id="brief_of_the_case" readonly class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Status:</label>
                        <select class="form-control" name="status" id="status">
                            <option selected disabled>Choose your status</option>
                            <option disabled value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                        </select>
                      </div> 
                      <div class="form-group">
                        <label for="usr">Remarks:</label>
                        <input type="text" name="remarks" id="remarks" class="form-control">
                      </div> 
                    </div>

                    <div class="modal-footer">
                      <button type="submit" name="updateData" class="btn btn-primary">Update</button>
                      <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
                    </div>
                  </form>
                </div>
              </div>
            </div>     

           
        
    </div>
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>



<script>
    


  $(document).ready( function () {
       $('.example').DataTable();
     });



   $(document).ready(function(){
       $('.deleteAdmin').on('click', function(){
           $tr = $(this).closest('tr');
           var data = $tr.children("td").map(function(){
               return $(this).text();
     //          console.log(data);
           }).get();
           $('#delete_id').val(data[0]);          
       });
   });


    $(document).ready(function(){
        $('.editBtnAdmin').on('click', function(){      
                $tr = $(this).closest('tr');
                var data = $tr.children("td").map(function(){
                    return $(this).text();
                }).get();
                 $('#update_admin_id').val(data[0]);
                 $('#case_id').val(data[1]);
                 $('#barangay').val(data[2]);
                 $('#complainant_name').val(data[3]);
                 $('#complainant_address').val(data[4]); 
                 $('#complainant_age').val(data[5]);
                 $('#respondent_name').val(data[6]); 
                 $('#respondent_address').val(data[7]); 
                 $('#respondent_age').val(data[8]); 
                 $('#brief_of_the_case').val(data[9]); 
                 $('#date').val(data[10]); 
                 $('#time').val(data[11]);   
        });
     });
</script>