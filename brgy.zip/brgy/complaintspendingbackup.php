
                    <!--   <div class="form-group">
                        <label for="usr">Complainant Name:</label>
                        <input type="text" name="complainant_name" id="complainant_name" class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Address:</label>
                        <input type="text" name="complainant_address" id="complainant_address" class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Age:</label>
                        <input type="number" name="complainant_age" id="complainant_age" class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Respondent Name:</label>
                        <input type="text" name="respondent_name" id="respondent_name" class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Address:</label>
                        <input type="text" name="respondent_address" id="respondent_address" class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Age:</label>
                        <input type="number" name="respondent_age" id="respondent_age" class="form-control">
                      </div> 
                      <div class="form-group">
                        <label for="usr">Brief of the Case:</label>
                        <textarea name="brief_of_the_case" id="brief_of_the_case" class="form-control"></textarea>
                      </div>
                    -->


                 // var complainantName = data[0].split(': ')[1];
                 // $('#complainant_name').val(complainantName);

                 // var complainantAddress = data[1].split(': ')[1];
                 // $('#complainant_address').val(complainantAddress); 

                 // var complainantAge = data[2].split(': ')[1];
                 // $('#complainant_age').val(complainantAge);

                 // var respondentName = data[3].split(': ')[1];
                 // $('#respondent_name').val(respondentName); 

                 // var respondentAddress = data[4].split(': ')[1];
                 // $('#respondent_address').val(respondentAddress);

                 // var respondentAge = data[5].split(': ')[1];
                 // $('#respondent_age').val(respondentAge);

                 // var briefOfTheCase = data[6].split(': ')[1];
                 // $('#brief_of_the_case').val(briefOfTheCase);