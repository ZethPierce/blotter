<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>DataTable Example</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.css"/>
  </head>
  <body>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Country</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>John Doe</td>
                <td>25</td>
                <td>USA</td>
            </tr>
            <tr>
                <td>Jane Doe</td>
                <td>32</td>
                <td>Canada</td>
            </tr>
            <tr>
                <td>Mark Smith</td>
                <td>45</td>
                <td>Australia</td>
            </tr>
        </tbody>
    </table>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.25/datatables.min.js"></script>
    <script>
      $(document).ready( function () {
        $('#example').DataTable();
      });
    </script>
  </body>
</html>
