<?php
include('connection.php');
session_start();
$username_session = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Brgy Blotter</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }

        a {
            text-decoration: none;
        }



</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('brgy_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>Pending Complaints</h1><br>
                <div class="row">              
                <?php 
                    $res = mysqli_query($conn, "SELECT * FROM tbl_complaints WHERE barangay='$username_session' AND status='Pending' ORDER BY id DESC");
                
                ?>       
                <?php while($row = mysqli_fetch_array($res)){ ?>         
                      <div class="col-lg-12 ">
                          <div class="card border-primary mb-3" >
                                <div class="card-header text-black" style="font-size: 1.5rem;"><?php echo $row["case_id"]; ?></div>
                                <div class="card-body ">           
                                <div>    
                                   <h6>ID: <?php echo $row["id"]; ?></h6>
                                   <h6>Case Number: <?php echo $row["case_id"]; ?></h6>
                                   <h6>Complainant Name: <?php echo $row["complainant_name"]; ?></h6>           
                                   <h6>Complainant Address: <?php echo $row["complainant_address"]; ?></h6>
                                   <h6>Complainant Age: <?php echo $row["complainant_age"]; ?></h6>
                                   <h6>Respondent Name: <?php echo $row["respondent_name"]; ?></h6>           
                                   <h6>Respondent Address: <?php echo $row["respondent_address"]; ?></h6>
                                   <h6>Respondent Age: <?php echo $row["respondent_age"]; ?></h6>
                                   <h6>Brief of the Case: <?php echo $row["brief_of_the_case"]; ?></h6>
                                   <h6>Date: <?php echo $row["date"]; ?></h6> 
                                   <h6>Time: <?php echo $row["time"]; ?></h6> 
                                   <h6>Status: <?php echo $row["status"]; ?></h6> 
                                   <h6>Remarks: <?php echo $row["remarks"]; ?></h6> 
                                  <button class="btn btn-primary mt-2 editBtnAdmin" data-toggle="modal" data-target="#editBtnAdmin">Solve It</button>
                                </div>
                          </div>  
                      </div>
                      <?php
                   }
                ?>  
                </div>
            </div>

            <div id="editBtnAdmin" class="modal fade" role="">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <form action="" method="post">
                  <div class="modal-header">
                    <h4 class="modal-title">Update</h4>
                  </div>     
                  <div class="modal-body">      
                    <input id="update_admin_id" name="update_admin_id" type="hidden">

                      <div class="form-group">
                        <label for="usr">Case Number:</label>
                        <input type="text" name="case_id" id="case_id"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Name:</label>
                        <input type="text" name="complainant_name" id="complainant_name"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Address:</label>
                        <input type="text" name="complainant_address" id="complainant_address"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Complainant Age:</label>
                        <input type="text" name="complainant_age" id="complainant_age"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Name:</label>
                        <input type="text" name="respondent_name" id="respondent_name"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Address:</label>
                        <input type="text" name="respondent_address" id="respondent_address"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Respondent Age:</label>
                        <input type="text" name="respondent_age" id="respondent_age"  class="form-control">
                      </div>
                      <div class="form-group">
                        <label for="usr">Brief of the Case:</label>
                        <input type="text" name="brief_of_the_case" id="brief_of_the_case"  class="form-control">
                      </div>

                      <div class="form-group">
                        <label for="usr">Status:</label>
                        <select class="form-control" name="status" id="status">
                            <option selected disabled>Choose your status</option>
                            <option disabled value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                        </select>
                      </div> 

                      <div class="form-group">
                        <label for="usr">Remarks:</label>
                        <input type="text" name="remarks" id="remarks" class="form-control">
                      </div> 

                    </div>

                    <div class="modal-footer">
                      <button type="submit" name="updateDataBrgy" class="btn btn-primary">Update</button>
                      <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>     
                    </div>
                  </form>
                </div>
              </div>
            </div>     

            <?php 
               if(isset($_POST['updateDataBrgy'])){    
                  $id = $_POST['update_admin_id'];
                  $case_id = mysqli_real_escape_string($conn, $_POST["case_id"]);
                  $complainant_name = mysqli_real_escape_string($conn, $_POST["complainant_name"]);
                  $complainant_address = mysqli_real_escape_string($conn, $_POST["complainant_address"]);  
                  $complainant_age = mysqli_real_escape_string($conn, $_POST["complainant_age"]);
                  $respondent_name = mysqli_real_escape_string($conn, $_POST["respondent_name"]);
                  $respondent_address = mysqli_real_escape_string($conn, $_POST["respondent_address"]);  
                  $respondent_age = mysqli_real_escape_string($conn, $_POST["respondent_age"]);
                  $brief_of_the_case = mysqli_real_escape_string($conn, $_POST["brief_of_the_case"]);
                  $status = mysqli_real_escape_string($conn, $_POST["status"]);
                  $remarks = mysqli_real_escape_string($conn, $_POST["remarks"]);
                  $query = mysqli_query($conn, "UPDATE tbl_complaints 
                    SET 
                    case_id='$case_id',
                    complainant_name='$complainant_name',
                    complainant_address='$complainant_address', 
                    complainant_age='$complainant_age',
                    respondent_name='$respondent_name',
                    respondent_address='$respondent_address', 
                    respondent_age='$respondent_age',
                    brief_of_the_case='$brief_of_the_case',
                    status='$status', 
                    remarks='$remarks'
                    WHERE id=$id");
                  if($query) {
                        $_SESSION['success'] = 'Successfully Updated'; // Set the success message in the session
                         echo '<script> window.location="brgy_complaints_pending.php";</script>';              
                      ;
                  }
               }
            ?>




              

        
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>



<script>
    
    $(document).ready(function(){
        $('.editBtnAdmin').on('click', function(){      
                $tr = $(this).closest('div');
                var data = $tr.children("h6").map(function(){
                    return $(this).text();
                }).get();
                 $('#update_admin_id').val(data[0]);

                 var caseID = data[1].split(': ')[1];
                 $('#case_id').val(caseID);
                 var complainantName = data[2].split(': ')[1];
                 $('#complainant_name').val(complainantName);
                 var complainantAddress = data[3].split(': ')[1];
                 $('#complainant_address').val(complainantAddress); 
                 var complainantAge = data[4].split(': ')[1];
                 $('#complainant_age').val(complainantAge);
                 var respondentName = data[5].split(': ')[1];
                 $('#respondent_name').val(respondentName); 
                 var respondentAddress = data[6].split(': ')[1];
                 $('#respondent_address').val(respondentAddress);
                 var respondentAge = data[7].split(': ')[1];
                 $('#respondent_age').val(respondentAge);
                 var briefOfTheCase = data[8].split(': ')[1];
                 $('#brief_of_the_case').val(briefOfTheCase);
                 var Status = data[9].split(': ')[1];
                 $('#status').val(Status);
                 var Remarks = data[12].split(': ')[1];
                 $('#remarks').val(Remarks);



        });
     });
</script>