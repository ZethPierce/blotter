<style>
     .list-group-item{
        border:  1px solid white;
    }

    .list-group-item-light {
        color:  #41464b;
    }

    #sidebar-wrapper {
        background: white !important;
    }

    .list-group-item {
        background: white;
        color:  blue;
        border: solid 5px white;
        zoom:  100%;
    }

    .list-group-item:hover {
        background: #1e1ee7;
        color:  white;

    }

    .list-group-item.active {
  background-color: #3939ff;
  border-color: #3939ff;
}


    hr {


  border-top: 1px solid rgba(0, 0, 0, 0.1);
}
    
</style>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<div class="border-end" id="sidebar-wrapper"> 
    <center>
<div class="sidebar-heading " style="margin-top: 30px; margin-bottom: 30px; color: #7975fe; background: white;"> 
    <img class="img-fluid" src="img/logo.png" width="150" style="height: 150px;">
 </div> 
</center>
    <div class="list-group list-group-flush">
     
    <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_manage_complaints.php') !== false) echo 'active'; ?>" href="admin_manage_complaints.php">
      &nbsp; Manage Complaints
    </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_manage_users.php') !== false) echo 'active'; ?>" href="admin_manage_users.php">
        &nbsp; Manage Users
      </a>


      <!-- <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_change_pass.php') !== false) echo 'active'; ?>"   href="admin_change_pass.php">
        &nbsp; Change Password
      </a> -->
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'logout.php') !== false) echo 'active'; ?>" href="logout.php">
        &nbsp; Log Out
      </a>
      
    </div>
</div>

