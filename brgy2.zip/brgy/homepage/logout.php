<?php
session_start();

unset($_SESSION['username']);

echo 
'
	<script>window.location = "homepage/index.php"; </script>
'


?>