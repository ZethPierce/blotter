<?php
// Connect to the database using MySQLi (procedural style)
$mysqli = mysqli_connect('localhost', 'username', 'password', 'mydatabase');

// Check for errors
if (mysqli_connect_errno()) {
  die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

// Decode the signature data from Base64
$signatureData = $_POST['signatureData'];
$signatureBlob = base64_decode(str_replace('data:image/png;base64,', '', $signatureData));

// Prepare the SQL statement and bind the parameters
$stmt = mysqli_prepare($mysqli, 'INSERT INTO signatures (name, signature) VALUES (?, ?)');
mysqli_stmt_bind_param($stmt, 'sb', $_POST['name'], $signatureBlob);

// Execute the statement and check for errors
if (!mysqli_stmt_execute($stmt)) {
  die('Error: (' . mysqli_errno($mysqli) . ') ' . mysqli_error($mysqli));
}

// Close the statement and database connection
mysqli_stmt_close($stmt);
mysqli_close($mysqli);
?>
