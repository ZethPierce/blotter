<?php 
require_once "controlleruserdata.php"; 
include('connection.php');
include('tags.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="style.css">
    <style>
        .borderimg {
            border: solid 1px black; padding: 5px 35px 5px 35px; border-radius: 5px; margin-top: 15px; margin-bottom: 15px;
        }
        .btn-primary {
            background: #3d96ff;
            border-color: #3d96ff;
        }
        .btn-primary:hover {
            background: #1577ea;
            border-color: #1577ea;
        }
        .btn-admin{
            background: #468598; 
            color: white; 
            margin-top: 15px;
        }
        .btn-admin:hover{
            background: #1e677d; 

        }

    </style>
</head>
<body>
    <div class="container" style="max-width: 350px; zoom: 120%;">
        <div style="font-size: 2rem; margin-top: 15px; margin-left: -25px;">
            <a href="index.php"><button class="btn btn-light">Back</button></a>
        </div> 
        <div class="row text-center align-items-center h-100 mx-auto justify-content-center align-items-center" style="">
            <div class="login-form ">
                 <img class="img-fluid" src="img/logo.png" width="150">
                <form action="user_login.php" method="POST" autocomplete="">
                     <h2 class="text-center">User Login Form</h2>
                    <p class="text-center">Login with your username and password.</p> 
                   
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>


                   
                    <hr/>
                    <div class="form-group">
                        <input class="form-control" type="text" name="username" placeholder="Username" required value="<?php echo $username ?>">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                    </div>
                    <!-- <span style="text-align: right !important; margin-top: -10px; margin-bottom: 15px; float: right;">Forgot as Password</span> -->
                   
                    <div class="form-group">
                        <input class="form-control button btn-primary" type="submit" name="login_user" value="Login" >
                    </div>
                    Doesn't Have An Account? <a href="user_registration.php">Sign Up</a>
                
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>