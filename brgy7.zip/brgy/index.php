<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<?php
include('connection.php');

session_start();  
//  if(!isset($_SESSION["username"]))  
//  {  
//       header("location:login.php");  
//       exit();
//  }  

// ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
     <title>Brgy Blotter</title>
     <link rel="stylesheet" type="text/css" href="style.css">


</head>

<body>

    <!-- Navigation -->
	<?php 
		include('header_index.php');
	?>

    <!-- Page Content -->
    <div class="container-fluid fontStyle">
        <div class="content-wrapper">
		<center>
            <div class="row" style="max-width: 1600px;">
                <div class="col-md-6 col-lg-6 text-left">
                    <p>
                    <h1 class="font arrange-content left-pad" style="color: #3939ff;"><span style="color: black;">Welcome to our</span> <br/> <b>Barangay Blotter System!</b></h1>
                    </p>
                    <p class="description left-pad"> The Barangay Blotter App serves as a convenient platform for residents residing in San Simon, Pampanga, to voice their complaints or express their concerns regarding their respective barangays. Through the utilization of this user-friendly application, individuals can easily submit their feedback and bring attention to various issues within their communities.<br/></p>
                    <div class="left-pad">
						<a href="user_registration.php">
                            <button type="button" class=" btn btn-default" 
						style="width: 242px; height: 57px; font-weight: bold; border-radius: 50px; 
						transition: .3s ease-in-out; background: #3939ff;color: white;">
								REGISTER
						</button>
                    </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 text-left ">
                    <img  src="img/brgy.png"  class="hidden-xs hidden-sm laptop arrange-content" alt="evernote image" >
                </div>
            </div>
			</center>
        </div>
    </div>

</body>

</html>
