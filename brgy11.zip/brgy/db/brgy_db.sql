-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2023 at 10:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brgy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `barangay` text DEFAULT NULL,
  `complaint` longtext NOT NULL,
  `file` text NOT NULL,
  `status` varchar(200) DEFAULT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(100) NOT NULL,
  `phone_number` bigint(20) DEFAULT NULL,
  `nature_of_incident` varchar(200) NOT NULL,
  `incident_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `username`, `barangay`, `complaint`, `file`, `status`, `date`, `time`, `phone_number`, `nature_of_incident`, `incident_name`) VALUES
(1, 'user', 'De La Paz', 'g421414', 'NULL', 'Pending', '2023-10-27', '08:04:40', 4211, 'Civil Case', ''),
(2, 'user', 'Concepcion', '321', 'NULL', 'Pending', '2023-10-27', '14:05:44', 321, 'Civil Case', '321'),
(3, 'user', 'Concepcion', '123', 'NULL', 'Pending', '2023-10-27', '14:07:35', 123, 'Civil Case', '123'),
(4, '', 'San Juan (Poblacion)', 'n42', 'NULL', 'Pending', '2023-10-27', '14:18:49', 42, 'Others', 'n42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '$2y$10$meq/ukdHTy3KQTasZKw88u8EImPx1wA5T4LhSkxzEqKMTqvJn4TFO');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brgy_credentials`
--

CREATE TABLE `tbl_brgy_credentials` (
  `id` int(55) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_brgy_credentials`
--

INSERT INTO `tbl_brgy_credentials` (`id`, `username`, `password`) VALUES
(1, 'Concepcion', '$2y$10$VO0nq6QEim6TPmYVCe3V5.BTXbPIjbVrogwNb092mJu.HSRgJ2Hz.'),
(2, 'De La Paz', '$2y$10$MoTKVBxR4.U3frd5etKLkeaLB/kFBwAZ6Xco1FjYwHpAag14N.oSq'),
(3, 'San Juan (Poblacion)', '$2y$10$0yvC.d9A96ulF/iRQp1vdurLPInwKKv/EtHw.GAKqHRVZb5iqX5w6'),
(4, 'San Agustin', '$2y$10$0lKHsPaangZxdSvDq0r0Be5FMfuUREbdJpmvEEIOXPV8c90aKkDiK'),
(5, 'San Isidro', '$2y$10$nHBLPbGgAkfvu4yAQyvCp./eCy1RVUdnO3N157PtGnTvIGFiWoI5i'),
(6, 'San Jose', '$2y$10$Aq2vmelS5S6bJ95fatsrL.6abmSoMzxDQBg9CSmfr4YSJhl2vVo1K'),
(7, 'San Miguel', '$2y$10$wchgsOgyH9KjgjXJF7Q8vuvmtO0Tpukadj5OQipli9w6Z6tg9VizO'),
(8, 'San Nicolas', '$2y$10$GA3qxkcXhbC9DROb5Pmes.cuK.J49ask7wTTVOsuoOTVoKMAK3ou2'),
(9, 'San Pablo Libutad', '$2y$10$hdPZxWAnV6DIR53UOHKEK.GlG6RbDSh4Cu8HnyOZMeWi9YnHjT5Ra'),
(10, 'San Pablo Proper', '$2y$10$zQLZsI/V/WfO97LhkT1THuHXEDLPOwW2Bz2PAWpYjOAwphPbGI8mq'),
(11, 'San Pedro', '$2y$10$rzLQ7BqLCESqRQc9nVtnZ.I0GXzm7Xt8jJKLVG8QHt.v1UIbtEmvO'),
(12, 'Santa Cruz', '$2y$10$.OESaP7lCWURZh4o7KTg2.b1m1JScCtWAhva.GviuHRFLg4Lz9Niy'),
(13, 'Santa Monica', '$2y$10$7XElxKdOdhha6pADi/KmP.EH0v3wqMv1.KDct0GwMUd6Hm.5Sm3ya'),
(14, 'Santo Nino', '$2y$10$T88v8ZozmO1NhTh84en/huH1x65SzLdMpUnrU.IfAzC0Gliuuh2ue');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaints`
--

CREATE TABLE `tbl_complaints` (
  `id` int(11) NOT NULL,
  `case_id` varchar(200) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `complainant_name` varchar(255) NOT NULL,
  `complainant_address` varchar(255) NOT NULL,
  `complainant_age` varchar(20) NOT NULL,
  `respondent_name` varchar(255) NOT NULL,
  `respondent_address` varchar(255) NOT NULL,
  `respondent_age` varchar(20) NOT NULL,
  `brief_of_the_case` longtext NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_complaints`
--

INSERT INTO `tbl_complaints` (`id`, `case_id`, `barangay`, `complainant_name`, `complainant_address`, `complainant_age`, `respondent_name`, `respondent_address`, `respondent_age`, `brief_of_the_case`, `status`, `date`, `time`) VALUES
(1, '123123', '123123', '123123', '123123', '123123', '123123', '123123', '123123', '123123', 'Pending', '2023-10-28', '14:55:22'),
(2, 'b42b424b2', 'b42b424b2', 'b42b424b2', 'b42b424b2', '424242', 'b42b424b2', 'b42b424b2', '424242', 'b42b424b2', 'Pending', '2023-10-28', '14:55:51'),
(3, '123', '123', '123', '123', '123', '123', '123', '123', '123', 'Pending', '2023-10-28', '15:14:14'),
(4, '424242', 'San Juan (Poblacion)', '4242', '4242', '4242', '4242', '4242', '4242', '4242', 'Pending', '2023-10-28', '15:19:02'),
(5, '3g21g31g3', 'Concepcion', '3g21g31g3', '3g21g31g3', '321313', '3g21g31g3', '3g21g31g3', '321313', '3g21g31g3', 'Pending', '2023-10-28', '15:19:12'),
(6, '123123', 'De La Paz', '123123', '123123', '123123', '123123', '123123', '123123', '123123', 'Pending', '2023-10-28', '15:21:01'),
(7, '321321', 'De La Paz', '321', '321', '321', '321', '321', '321', '321', 'Pending', '2023-10-28', '15:22:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resolve`
--

CREATE TABLE `tbl_resolve` (
  `id` int(55) NOT NULL,
  `case_id` varchar(55) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `remarks` longtext NOT NULL,
  `status` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(55) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `username`, `password`, `phone_number`, `address`) VALUES
(1, '4242', '4242', '4242', '$2y$10$Ymv/Wi8dF4EyzbmtR4ofGu6S5DBofEnuNcOhXXb3kFRZxlLQ3rexK', '4242', '424245'),
(2, 'user', 'user', 'user', '$2y$10$FDyteJ06cBxrdYoJBHyL3eLuKUKpSJz2qvWikgbDIFxnWDPRS4CfO', '', ''),
(3, '4242424', '4242424', '4242424', '$2y$10$eLaqzCX8RcU02IUg0jwMcO/2uFYxH02JEBpN.7MMychX7kPySEfHe', '4242424', '4242424'),
(4, 'asd123', '123', 'asd123', 'asd123', '123', 'asd123'),
(5, '321asd', '321', '321asd', '$2y$10$OeXrIBQsy7f7C83rvTNHuup5FzPh46qNNA5ineeRPqQ7AzFbEgX7C', '321', '321asd'),
(6, 'zxc123', '123', 'zxc123', '$2y$10$DzbKOqLyWr24tUsFOjPGyOOI/JZo9c5LQr/0.rDT.LqciND8zZigK', '123', 'zxc123'),
(7, 'zxc123', '123', 'zxc123', '$2y$10$iCqPKncDU9UzHFdWfbmaEut8hX3UByzBR.YbSz3w6QSybfjMnIreG', '123', 'zxc123'),
(8, 'zxc123', '123', 'zxc123', '$2y$10$jjJ4/Ngx0UAcVMVkHNRwDerg.7GB8XADvu0BXdC/xpRv7rkU7imGK', '123', 'zxc123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_brgy_credentials`
--
ALTER TABLE `tbl_brgy_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_complaints`
--
ALTER TABLE `tbl_complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_resolve`
--
ALTER TABLE `tbl_resolve`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_brgy_credentials`
--
ALTER TABLE `tbl_brgy_credentials`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_complaints`
--
ALTER TABLE `tbl_complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_resolve`
--
ALTER TABLE `tbl_resolve`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
